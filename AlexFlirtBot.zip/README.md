# AlexFlirtBot

Flirty Telegram AI bot for Fanvue funnel.